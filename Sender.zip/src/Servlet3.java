import javax.ejb.EJB;

/**
 * Created by Kamil on 30.04.2017.
 */
@javax.servlet.annotation.WebServlet(urlPatterns = "/servlet3")
public class Servlet3 extends javax.servlet.http.HttpServlet {

    @EJB
    MessageSender sender;

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
        String s = request.getParameter("tresc");
        String t = request.getParameter("type");

        sender.sendMessageList(s,t);
    }
}
