import javax.ejb.EJB;
import java.util.ArrayList;

/**
 * Created by Kamil on 01.05.2017.
 */
@javax.servlet.annotation.WebServlet(urlPatterns = "/servlet4")
public class Servlet4 extends javax.servlet.http.HttpServlet {

    @EJB
    MessageSender sender;

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
        String s = request.getParameter("tresc");
        String[] t = request.getParameterValues("type");

        ArrayList<String> t2 = new ArrayList<>();
        for (String s2:t) {
            t2.add(s2);
        }
        sender.dodaj(s,t2);
        request.getRequestDispatcher("index.jsp").forward(request,response);

    }
}
