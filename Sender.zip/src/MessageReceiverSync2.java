import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.jms.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Enumeration;

@Stateless
public class MessageReceiverSync2 extends Receiver {


}