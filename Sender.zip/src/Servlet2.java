import javax.ejb.EJB;
import java.util.ArrayList;

/**
 * Created by Kamil on 30.04.2017.
 */
@javax.servlet.annotation.WebServlet(urlPatterns = "/servlet2")
public class Servlet2 extends javax.servlet.http.HttpServlet {

    @EJB
    MessageSender sender;

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {

    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {

        request.setAttribute("data",sender.getLista());
        request.setAttribute("topic",sender.topics());
        request.getRequestDispatcher("main.jsp").forward(request,response);
    }
}
