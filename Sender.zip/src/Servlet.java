import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by Kamil on 28.04.2017.
 */
@WebServlet(urlPatterns = "/servlet")
public class Servlet extends HttpServlet {

    @EJB
    MessageSender sender;

    @EJB
    MessageReceiverSync2 receiverSync2;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response,String tresc,String typ)
        throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        out.println("");
        out.println("");
        String m = "Wysylam wiadomosc";
        sender.sendMessage(tresc,typ);
        out.println("Sending message...");

        out.println("");
        out.println("");

        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String s = request.getParameter("tresc");
        String t = request.getParameter("type");


        processRequest(request,response,s,t);
    }
}
