import javax.annotation.Resource;
import javax.jms.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Enumeration;

/**
 * Created by Kamil on 29.04.2017.
 */
public class Receiver implements MessageListener{

    @Resource(mappedName = "java:/ConnectionFactory")
    private TopicConnectionFactory connectionFactory;

    //@Resource(mappedName = "jms/myQueue")
    //Queue myQueue;

    private String message;

    public String receiveMessage() {
        try {
            InitialContext context = new InitialContext();
            Topic queue = (Topic) context.lookup("java:/jms/topics/Topic");
            TopicConnection connection = connectionFactory.createTopicConnection();
            TopicSession session = connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
            TopicSubscriber subscriber = session.createSubscriber(queue);
            connection.start();


            //MyListener listener = new MyListener();
            subscriber.setMessageListener(this);


        } catch (JMSException e) {
            e.printStackTrace();
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return "";
    }

    @Override
    public void onMessage(Message message) {
        try{
            TextMessage msg=(TextMessage)message;

            System.out.println("following message is received:"+msg.getText());
        }catch(JMSException e){System.out.println(e);}
    }
}
