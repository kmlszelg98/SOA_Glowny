import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.context.ApplicationScoped;
import javax.jms.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.ArrayList;
import java.util.HashMap;

@Stateless
public class MessageSender {

    public ArrayList<String> lista = new ArrayList<>();
    public HashMap<String,ArrayList<String>> tematy = new HashMap<>();

    @PostConstruct
    public void start(){
        lista.add("R1");
        lista.add("R2");
        lista.add("R3");
    }

    public ArrayList<String> topics(){
        ArrayList<String> l = new ArrayList<>();
        tematy.forEach((k,v) -> l.add(k));
        return l;
    }

    public ArrayList<String> getLista() {
        return lista;
    }

    public ArrayList<String> setup(){
        lista.add("R1");
        lista.add("R2");
        lista.add("R3");
        System.out.println("End");
        return lista;
    }

    @Resource(mappedName = "java:/ConnectionFactory")
    private TopicConnectionFactory cf;

    public void sendMessageList(String message,String nazwa){
        ArrayList<String> l = tematy.get(nazwa);
        for (String s:l) {
            sendMessage(message,s);

        }
    }

    public void dodaj(String name, ArrayList<String> t){
        tematy.put(name,t);
    }


    public void sendMessage(String message,String typ) {

        MessageProducer messageProducer;
    TextMessage textMessage;
    try {
    TopicConnection connection = cf.createTopicConnection();
    connection.start();
    InitialContext context = new InitialContext();
    Topic topic = (Topic) context.lookup("java:/jms/topics/Topic");
    TopicSession session = connection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
    TopicPublisher publisher = session.createPublisher(null);
    textMessage = session.createTextMessage();

    textMessage.setText(message);
    textMessage.setStringProperty("typ",typ);
    publisher.send(topic,textMessage);
    //messageProducer.send(topic,textMessage);
    //messageProducer.close();
        publisher.close();
    session.close();
    connection.close();
    } catch (JMSException e) {
    e.printStackTrace();
    } catch (NamingException e) {
        e.printStackTrace();
    }
    }
}